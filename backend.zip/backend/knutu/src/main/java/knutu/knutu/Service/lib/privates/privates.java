package knutu.knutu.Service.lib.privates;

public class privates {
    public static final String keyURL = "src/main/resources/serviceAccountKey.json";
    public static final String dbURL = "https://knutu-3e04f-default-rtdb.asia-southeast1.firebasedatabase.app";
    public static final String stdictAuthKey = "CC0DA6B0635DAD91A435F6EEDFFFD8A5";
}