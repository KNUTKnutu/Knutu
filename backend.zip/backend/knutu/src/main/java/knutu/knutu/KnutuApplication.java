package knutu.knutu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KnutuApplication {

	public static void main(String[] args) {
		SpringApplication.run(KnutuApplication.class, args);
	}

}
